export const state = {
  user: { id: 'abc123', name: 'Adam' }
}
